# Software Testing Code Assistant

This extension helps you generate software tests.

## Features

- Scan the open file for function definitions
- Display scanned functions in a Tree View
- Open a Test Suite page to view and save test cases

## Commands

- `Scan Functions`: Scans the open file for function definitions
- `Open Test Suite`: Opens the Test Suite page

## Requirements

None.

## Extension Settings

None.

## Known Issues

None.

## Release Notes

### 0.0.1

Initial release of Software Testing Code Assistant.
