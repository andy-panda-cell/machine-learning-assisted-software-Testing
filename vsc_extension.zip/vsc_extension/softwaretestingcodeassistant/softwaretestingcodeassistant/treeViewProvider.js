const vscode = require('vscode');
const path = require('path');
const fs = require('fs');
const ignore = require('ignore');

class TestSuiteProvider {
  constructor(context) {
    this.context = context;
    this._onDidChangeTreeData = new vscode.EventEmitter();
    this.onDidChangeTreeData = this._onDidChangeTreeData.event;
    this.ignoreRules = this.loadIgnoreRules();
  }

  loadIgnoreRules() {
    const ig = ignore().add([]);
    const workspaceFolders = vscode.workspace.workspaceFolders;

    if (workspaceFolders) {
      const rootPath = workspaceFolders[0].uri.fsPath;
      const gitignorePath = path.join(rootPath, '.gitignore');

      if (fs.existsSync(gitignorePath)) {
        const gitignoreContent = fs.readFileSync(gitignorePath, 'utf8');
        ig.add(gitignoreContent);
      }
    } else {
      vscode.window.showWarningMessage('No workspace folder found. Ignore rules will not be applied.');
    }

    // Additional ignore patterns
    ig.add(['.venv/', 'lib/', 'package/']);
    return ig;
  }

  refresh() {
    this._onDidChangeTreeData.fire();
  }

  getTreeItem(element) {
    return element;
  }

  getChildren(element) {
    if (!element) {
      return this.getFiles();
    } else {
      return this.getFunctionsInFile(element.resourceUri.fsPath);
    }
  }

  getFiles() {
    return vscode.workspace.findFiles('**/*.py').then(uris => {
      const workspaceFolders = vscode.workspace.workspaceFolders;
      if (workspaceFolders) {
        const rootPath = workspaceFolders[0].uri.fsPath;
        const filteredUris = uris.filter(uri => !this.ignoreRules.ignores(path.relative(rootPath, uri.fsPath)));
        return filteredUris.map(uri => new FileItem(uri));
      } else {
        vscode.window.showWarningMessage('No workspace folder found.');
        return [];
      }
    });
  }

  getFunctionsInFile(filePath) {
    return vscode.workspace.openTextDocument(filePath).then(doc => {
      const functionNames = [];
      const regex = /^def\s+(\w+)\s*\(/gm;
      let match;
      while ((match = regex.exec(doc.getText()))) {
        functionNames.push(new FunctionItem(match[1], filePath));
      }
      return functionNames;
    });
  }
}

class FileItem extends vscode.TreeItem {
  constructor(uri) {
    super(path.basename(uri.fsPath), vscode.TreeItemCollapsibleState.Collapsed);
    this.resourceUri = uri;
    this.contextValue = 'file';
  }
}

class FunctionItem extends vscode.TreeItem {
  constructor(functionName, filePath) {
    super(functionName, vscode.TreeItemCollapsibleState.None);
    this.resourceUri = vscode.Uri.file(filePath);
    this.contextValue = 'function';
  }
}

class FunctionTreeItem extends vscode.TreeItem {
  constructor(label) {
      super(label, vscode.TreeItemCollapsibleState.None);
      this.command = {
          command: 'softwaretestingcodeassistant.showFunction',
          title: 'Show Function',
          arguments: [label]
      };
  }
}

class FunctionTreeDataProvider {
  constructor(functions) {
      this.functions = functions;
  }

  getTreeItem(element) {
      return element;
  }

  getChildren() {
      return this.functions.map(func => new FunctionTreeItem(func));
  }
}

module.exports = {
  TestSuiteProvider,
  FunctionTreeDataProvider,
  FunctionTreeItem
};
