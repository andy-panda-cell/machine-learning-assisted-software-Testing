const vscode = require('vscode');
const fetch = require('node-fetch');
const path = require('path');


// Function to query the Huggingface API
async function query(data) {
    const response = await fetch(
        "#INSERT URL",
		{
			headers: { 
				"Accept" : "application/json",
				"Authorization": "Bearer #INSERT HUGGINGFACE API" ,
				"Content-Type": "application/json" 
			},
			method: "POST",
			body: JSON.stringify(data),
		}
    );

    const responseBody = await response.text(); // Get the response as text
    console.log(responseBody); // Print the response body for debugging

    try {
        return JSON.parse(responseBody); // Try to parse the response as JSON
    } catch (error) {
        throw new Error(`Invalid JSON response: ${responseBody}`); // Throw an error if parsing fails
    }
}


// Function to generate test code using Huggingface API
async function generateTestCode(code) {
    const prompt = `[INST] You are a helpful Software Testing Code Generation Tool which provides the test Code based on the Code. 
                    Do not give any extra information. Do not give repeat the context again in your response.\n
                    Generate a series of test cases that cover various edge cases.\n
                    Import unittest and use any unittest library that is necessary.\n
                    Return The Test cases description maximum of 5 that is being tested, and the test Code itself.\n
                    Generate within 400 token string for both the Test cases description and Test Code.
                    "Input": {${code}} [/INST]`;
    try {
        const response = await query({
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": 500,
                "return_full_text": false
            }
        });

        if (response && response.length > 0 && response[0].generated_text) {
            const generatedText = response[0].generated_text;
            const lines = generatedText.split('\n');
            const edgeCases = lines.slice(3, 8); // Extracting first 5 lines as edge cases
            const testCode = lines.slice(9).join('\n'); // Remaining lines as test code
            console.log(edgeCases);
            console.log(testCode);
            displayTestCasesInWebView(edgeCases, testCode);
        } else {
            displayTestCasesInWebView(["Error: Could not generate test code"], "");
        }
    } catch (error) {
        console.error('Error generating test code:', error);
        displayTestCasesInWebView(["Error: Could not generate test code"], "");
    }
}

// Tree view and file scanning classes
class TestSuiteProvider {
    constructor(context) {
        this.context = context;
        this._onDidChangeTreeData = new vscode.EventEmitter();
        this.onDidChangeTreeData = this._onDidChangeTreeData.event;
    }

    refresh() {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element) {
        return element;
    }

    getChildren(element) {
        if (!element) {
            return this.getFiles();
        } else {
            return this.getFunctionsInFile(element.resourceUri.fsPath);
        }
    }

    async getFiles() {
        const pattern = '**/*.py';
        const excludePattern = '**/venv/**';
        const allUris = await vscode.workspace.findFiles(pattern, excludePattern);
        console.log(allUris.map(uri => uri.path)); // Log all file paths to help identify the issue
        return allUris.map(uri => new FileItem(uri));
    }
    
    getFunctionsInFile(filePath) {
        if (filePath.includes('.venv')) {
            return Promise.resolve([]); // Ignore .venv directory
        }
    
        return vscode.workspace.openTextDocument(filePath).then(doc => {
            const functionNames = [];
            const regex = /^def\s+(\w+)\s*\(/gm;
            let match;
            while ((match = regex.exec(doc.getText()))) {
                functionNames.push(new FunctionItem(match[1], filePath));
            }
            console.log(functionNames);

            return functionNames;
        });
    }    
}

class FileItem extends vscode.TreeItem {
    constructor(uri) {
        super(path.basename(uri.fsPath), vscode.TreeItemCollapsibleState.Collapsed);
        this.resourceUri = uri;
        this.contextValue = 'file';
    }
}

class FunctionItem extends vscode.TreeItem {
    constructor(functionName, filePath) {
        super(functionName, vscode.TreeItemCollapsibleState.None);
        this.resourceUri = vscode.Uri.file(filePath);
        this.contextValue = 'function';
        this.command = {
            command: 'softwaretestingcodeassistant.generateTestCode',
            title: 'Generate Test Code',
            arguments: [functionName, filePath]
        };
    }
}

function cleanTestCode(testCode) {
    // Regex to remove whitespace after unittest.main()
    return testCode.replace(/(unittest\.main\(\))(\s+)$/, '$1');
}

// Function to display test cases in a webview
async function displayTestCasesInWebView(edgeCases, testCode) {
    testCode = cleanTestCode(testCode);  // Ensure the test code is clean

    if (!Array.isArray(edgeCases)) {
        edgeCases = ["No edge cases provided or error in fetching edge cases."];
    }

    const edgeCasesHtml = edgeCases.map(caseDesc => `<li>${caseDesc}</li>`).join('');

    const panel = vscode.window.createWebviewPanel(
        'generatedTestCases',
        'Generated Test Cases',
        vscode.ViewColumn.Beside,
        { enableScripts: true }
    );

    panel.webview.html = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Test Suite</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #282c34;
                    color: #abb2bf;
                    padding: 0;
                    margin: 0;
                }
                .header {
                    margin: 20px;
                    padding: 10px;
                    font-size: 18px;
                    font-weight: bold;
                }
                
                ul {
                    margin: 20px;
                }
                .container {
                    padding: 10px 20px 10px;
                }
                .button {
                    background-color: #61afef; /* Light blue background */
                    border: none; /* No border */
                    color: white; /* White text */
                    padding: 10px 20px; /* Top/bottom and left/right padding */
                    text-align: center; /* Center text inside the button */
                    text-decoration: none; /* No underline or other text decoration */
                    display: inline-block; /* Allows margin settings and more */
                    font-size: 16px; /* Text size */
                    margin: 4px 2px;
                    cursor: pointer; 
                    border-radius: 4px;
                    transition: background-color 0.3s, box-shadow 0.3s;
                }

                .button:hover {
                    background-color: #4095c6; 
                    box-shadow: 0 2px 5px rgba(0,0,0,0.2); 
                }
                .test-case {
                    background-color: #21252b;
                    margin: 25px 0;
                    padding: 10px;
                    border-radius: 4px;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                }
                .test-case .header {
                    font-size: 16px;
                    margin-bottom: 10px;
                }
                pre {
                    background-color: #2c313a;
                    padding: 15px;
                    border-radius: 4px;
                    overflow: auto;
                }
                ul {
                    list-style: none;
                    padding-left: 0;
                }
            </style>
        </head>
        <body>
            <div class="header">Test Cases</div>
            <ul>${edgeCasesHtml}</ul>
            <div class="header">Test Suite</div>
            <div class="container">
                <pre><code>${testCode}</code></pre>
                <button onclick="saveTestCode()">Save Test Code</button>
            </div>
            <script>
                const vscode = acquireVsCodeApi();
                function saveTestCode() {
                    const code = \`${testCode}\`;
                    vscode.postMessage({ command: 'saveTestCode', testCode: code });
                }
            </script>
        </body>
        </html>
    `;

    panel.webview.onDidReceiveMessage(message => {
        if (message.command === 'saveTestCode') {
            saveTestCode(message.testCode);
        }
    });
}




async function saveTestCode(testCode, functionName) {
    const date = new Date().toISOString().slice(0, 10); // Format as YYYY-MM-DD
    const header = `# Generated by VisualCodeExtension Date: ${date}\n`;

    const fileName = `generated_test_${functionName}.py`;
    const testCasesUri = vscode.Uri.file(`${vscode.workspace.rootPath}/${fileName}`);

    const fileContent = Buffer.from(`${header}${testCode}`, 'utf8');

    await vscode.workspace.fs.writeFile(testCasesUri, fileContent);
    vscode.window.showInformationMessage(`Test cases have been saved to ${fileName}`);
}


// Main activation function
function activate(context) {
    console.log('Extension "softwaretestingcodeassistant" is now active!');
    const testSuiteProvider = new TestSuiteProvider(context);

    context.subscriptions.push(vscode.commands.registerCommand('softwaretestingcodeassistant.refresh', () => {
        testSuiteProvider.refresh();
    }));

    context.subscriptions.push(vscode.commands.registerCommand('softwaretestingcodeassistant.generateTestCode', async (functionName, filePath) => {
        const doc = await vscode.workspace.openTextDocument(filePath);
        const code = doc.getText();
        const functionCodeRegex = new RegExp(`def\\s+${functionName}\\s*\\([^\\)]*\\):[\\s\\S]*?(?=def\\s+|\\Z)`, 'gm');
        const functionCode = (functionCodeRegex.exec(code) || [''])[0];
        console.log(functionCode);
        const testCode = await generateTestCode(functionCode);
        displayTestCasesInWebView(testCode);
    }));

    context.subscriptions.push(vscode.window.registerTreeDataProvider('functionView', testSuiteProvider));
}

function deactivate() {}

module.exports = {
    activate,
    deactivate
};
