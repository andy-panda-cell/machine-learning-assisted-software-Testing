const fetch = require('node-fetch');
const vscode = require('vscode');

async function query(data) {
    console.log('called query');
    const response = await fetch(
        "https://api-inference.huggingface.co/models/microsoft/Phi-3-mini-4k-instruct",
        {
            headers: { 
                "Content-Type": "application/json",
                Authorization: "Bearer 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",
            },
            method: "POST",
            body: JSON.stringify(data),
        }
    );

    console.log(response);
    const result = await response.json();
    console.log(result);
    return result;
}

function parseGeneratedText(response) {
    if (!Array.isArray(response) || response.length === 0 || !response[0].generated_text) {
        throw new Error('Invalid response format');
    }
    const generatedText = response[0].generated_text;
    const splitText = generatedText.split('\n\n');
    if (splitText.length < 2) {
        throw new Error('Generated text does not contain expected format');
    }
    return splitText[1].trim();
}

function extractFunctionsFromCode(code) {
    const functionRegex = /def\s+(\w+)\s*\(/g;
    const functions = [];
    let match;
    while (match = functionRegex.exec(code)) {
        functions.push(match[1]);
    }
    return functions;
}

module.exports = {
    query,
    parseGeneratedText,
    extractFunctionsFromCode
};
